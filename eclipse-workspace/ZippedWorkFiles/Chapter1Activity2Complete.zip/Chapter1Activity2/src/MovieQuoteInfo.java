
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("\"The light that burns twice as bright burns half as long - and you have burned so very, very brightly, Roy.\"");
		System.out.println(" - Dr. Eldon Tyrell (Blade Runner, 1982)");

		//was this supposed to be output across multiple lines? I feel like I'm misunderstanding the assignment.
	}

}

//Alex McLaurin 9/3/24 Write a class that displays 3 initials with a period following each one. Using J, M, and F as the initials.

public class Initials {

	public static void main(String[] args) {
		
		var init1 = "J";
		var init2 = "M";
		var init3 = "F";
		
		System.out.println(init1+"."+init2+"."+init3);

	}

}

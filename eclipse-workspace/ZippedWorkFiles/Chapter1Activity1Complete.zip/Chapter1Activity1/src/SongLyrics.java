//Alex McLaurin 8/15 ch1 ex1

public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Oh it's a long way forward, trust in me");
		System.out.println("I'll give them shelter like you've done for me");
		System.out.println("And I know I'm not alone, you'll be watching over us");
		System.out.println("Until you're gone");
	}

}

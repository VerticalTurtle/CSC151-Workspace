
public class Triangle {

	public static void main(String[] args) {
		System.out.println("      T       ");
		System.out.println("     TTT      ");
		System.out.println("    TTTTTT    ");
		System.out.println("   TTTTTTTT   ");
		System.out.println("  TTTTTTTTTT  ");
		System.out.println(" TTTTTTTTTTTT ");
		System.out.println("TTTTTTTTTTTTTT");
	}

}
